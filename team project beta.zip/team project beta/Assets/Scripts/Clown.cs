using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.UI;
public class Clown : MonoBehaviour
{
    [SerializeField]
    private Transform target = null;
    private NavMeshAgent nav_mesh_agent;
    Vector3 Goal_pos;
    int rnd = 0;
    // Start is called before the first frame update
    void Start()
    {
        nav_mesh_agent = GetComponent<NavMeshAgent>();
        rnd = Random.Range(1, 5);

        switch (rnd)
        {
            case 1:
                {
                    target = GameObject.Find("Wandering point 1").transform;
                    break;
                }
            case 2:
                {
                    target = GameObject.Find("Wandering point 2").transform;

                    break;
                }
            case 3:
                {
                    target = GameObject.Find("Wandering point 3").transform;

                    break;
                }
            case 4:
                {
                    target = GameObject.Find("Wandering point 4").transform;

                    break;
                }
            default:
                {
                    break;
                }
        }


        if (target)
            nav_mesh_agent.destination = target.position;
    }

    // Update is called once per frame
    void Update()
    {
    }
    void OnCollisionEnter(Collision collision)
    {
        Debug.Log("�����ɓ�������");
        int rnd = 0;
        if (collision.gameObject.tag == "Point1"&&target== GameObject.Find("Wandering point 1").transform)
        {
            Debug.Log("�P�ɓ�������");
            while (target == GameObject.Find("Wandering point 1").transform)
            {
                rnd = Random.Range(1, 5);
                switch (rnd)
                {
                    case 2:
                        {
                            target = GameObject.Find("Wandering point 2").transform;

                            break;
                        }
                    case 3:
                        {
                            target = GameObject.Find("Wandering point 3").transform;

                            break;
                        }
                    case 4:
                        {
                            target = GameObject.Find("Wandering point 4").transform;

                            break;
                        }
                    default:
                        break;
                }
            }
            if (target)
                nav_mesh_agent.destination = target.position;
            return;
        }

        if (collision.gameObject.tag == "Point2" && target == GameObject.Find("Wandering point 2").transform)
        {
            Debug.Log("�Q�ɓ�������");
            while (target == GameObject.Find("Wandering point 2").transform)
            {

                rnd = Random.Range(1, 5);
                switch (rnd)
                {
                    case 1:
                        {
                            target = GameObject.Find("Wandering point 1").transform;

                            break;
                        }
                    case 3:
                        {
                            target = GameObject.Find("Wandering point 3").transform;

                            break;
                        }
                    case 4:
                        {
                            target = GameObject.Find("Wandering point 4").transform;

                            break;
                        }
                    default:
                        break;
                }
            }
            if (target)
                nav_mesh_agent.destination = target.position;
            return;

        }

        if (collision.gameObject.tag == "Point3" && target == GameObject.Find("Wandering point 3").transform)
        {
            Debug.Log("�R�ɓ�������");

            while(target == GameObject.Find("Wandering point 3").transform)
            {
                rnd = Random.Range(1, 5);
                switch (rnd)
                {
                    case 2:
                        {
                            target = GameObject.Find("Wandering point 2").transform;

                            break;
                        }
                    case 1:
                        {
                            target = GameObject.Find("Wandering point 1").transform;

                            break;
                        }
                    case 4:
                        {
                            target = GameObject.Find("Wandering point 4").transform;

                            break;
                        }
                    default:
                        break;
                }
            }

            if (target)
                nav_mesh_agent.destination = target.position;
            return;

        }

        if (collision.gameObject.tag == "Point4" && target == GameObject.Find("Wandering point 4").transform)
        {
            Debug.Log("�S�ɓ�������");
            while (target == GameObject.Find("Wandering point 4").transform)
            {

                rnd = Random.Range(1, 5);
                switch (rnd)
                {
                    case 2:
                        {
                            target = GameObject.Find("Wandering point 2").transform;

                            break;
                        }
                    case 3:
                        {
                            target = GameObject.Find("Wandering point 3").transform;

                            break;
                        }
                    case 1:
                        {
                            target = GameObject.Find("Wandering point 1").transform;

                            break;
                        }
                    default:
                        break;
                }
            }

            if (target)
                nav_mesh_agent.destination = target.position;
            return;

        }
    }
}

