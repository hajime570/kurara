using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 10.0f;
    public float Rotation = 0.1f;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 pos = transform.position;
        Vector3 rot = transform.localEulerAngles;

        if(Input.GetKey(KeyCode.W))
        {
            pos.x -= speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.S))
        {
            pos.x += speed * Time.deltaTime;

        }

        if (Input.GetKey(KeyCode.A))
        {
            pos.z -= speed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.D))
        {
            pos.z += speed * Time.deltaTime;
        }

        if (Input.GetKey(KeyCode.LeftArrow))
        {
            rot.y += Rotation;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            rot.y -= Rotation;
        }

        transform.position = pos;
        transform.localEulerAngles = rot;

    }
}
